#v0.1.0
- Dynamic Volume Provisioner for K8s - hyper converged cloud native storage - OpenEBS.
- Support for creating and deleting of OpenEBS Volumes - for the PVCs pointing to Storage Class (openebs.io/provisioner-iscsi)
- Support for attaching the OpenEBS storage to Pods via iSCSI
- Satyam Zode <satyam.zode@openebs.io>
