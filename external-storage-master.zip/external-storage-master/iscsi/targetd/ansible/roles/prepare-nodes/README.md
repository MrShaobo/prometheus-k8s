## Here are the variables used by this role:

| variable  | optionality  | default  | description  |
|:-:|:-:|:-:|:-:|
| iscsi_initiator_name | mandatory |  | name of the iscsi initiators, this must be a host var different for each initiator |