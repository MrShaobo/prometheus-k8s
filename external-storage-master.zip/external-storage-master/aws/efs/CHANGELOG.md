# v0.1.2
- Add 'gidAllocate' storageClass param for disabling gid allocation (#329)

# v0.1.1
- Print all non-efs mount entries when efs mount entry is not found, for easier debugging (#298)

# v0.1.0
- Initial release
