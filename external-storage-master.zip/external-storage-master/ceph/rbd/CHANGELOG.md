# v0.1.1
- Use provisioner name as identity by default instead of random string. (https://github.com/kubernetes-incubator/external-storage/pull/267)
- Add PROVISIONER_NAME environment variable support (https://github.com/kubernetes-incubator/external-storage/pull/267)

# v0.1.0
- Initial release