# v0.1.2
- Use provisioner name as identity by default instead of random string. See #267. (https://github.com/kubernetes-incubator/external-storage/pull/270)
- Add PROVISIONER_NAME environment variable support (https://github.com/kubernetes-incubator/external-storage/pull/270)

# v0.1.1
- Fix docker file error "chmod: invalid mode: 'x+o'" (https://github.com/kubernetes-incubator/external-storage/pull/215)

# v0.1.0
- Initial release