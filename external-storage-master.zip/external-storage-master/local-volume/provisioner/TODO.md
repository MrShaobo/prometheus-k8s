# TODO

## P0
* Redesign for security hardening (verult)

## P1

## P2
* Dynamic provisioning using lvm
* Partitioning, formatting, and mount extensions
* Refactor to just use informer's cache (and need to stub out API calls for unit
  testing)
