# v2.0.0
- Reformat error strings [CNS 3.9].
- Humble Chirammal <hchiramm@redhat.com>

# v1.0.3
- Pull heketi hash of gluster block API merge.
- Humble Chirammal <hchiramm@redhat.com>

# v1.0.2
- with CHAP support
- Humble Chirammal <hchiramm@redhat.com>

# v1.0.0
- with manual heketi vendor update and working heketi opmode [CNS 3.6].
- Humble Chirammal <hchiramm@redhat.com>

# v0.9
- Working provisioner which only enabled gluster-block opmode.
- Humble Chirammal <hchiramm@redhat.com>

# v0.0
- Initial drop of Gluster Block Provisioner.
- Humble Chirammal <hchiramm@redhat.com>

