This directory hosts external kubernetes provisioners for  gluster file and block. Please refer file provisioner readme 
[readme](https://github.com/kubernetes-incubator/external-storage/blob/master/gluster/file/README.md) and block provisioner [readme](https://github.com/kubernetes-incubator/external-storage/blob/master/gluster/block/README.md) for more details.
